#import <Foundation/Foundation.h>
@interface PodsDummy_nanopb : NSObject
@end
@implementation PodsDummy_nanopb
@end
