#import <Foundation/Foundation.h>
@interface PodsDummy_Pods_ld : NSObject
@end
@implementation PodsDummy_Pods_ld
@end
