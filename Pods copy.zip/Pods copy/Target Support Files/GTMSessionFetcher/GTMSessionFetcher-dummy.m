#import <Foundation/Foundation.h>
@interface PodsDummy_GTMSessionFetcher : NSObject
@end
@implementation PodsDummy_GTMSessionFetcher
@end
