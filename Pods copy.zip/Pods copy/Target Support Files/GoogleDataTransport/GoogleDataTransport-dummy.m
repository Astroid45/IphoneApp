#import <Foundation/Foundation.h>
@interface PodsDummy_GoogleDataTransport : NSObject
@end
@implementation PodsDummy_GoogleDataTransport
@end
